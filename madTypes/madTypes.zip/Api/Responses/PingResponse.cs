﻿namespace madTypes.Api.Responses;

public record PingResponse(string Message);
