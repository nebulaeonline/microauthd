﻿namespace madTypes.Api.Requests;

public sealed class AssignPermissionRequest
{
    public string PermissionId { get; set; } = string.Empty;
}
