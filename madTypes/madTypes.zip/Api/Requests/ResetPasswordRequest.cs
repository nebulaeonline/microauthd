﻿namespace madTypes.Api.Requests
{
    public class ResetPasswordRequest
    {
        public required string NewPassword { get; set; }
    }
}
