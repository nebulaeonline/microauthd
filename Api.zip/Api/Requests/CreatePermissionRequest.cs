﻿namespace madTypes.Api.Requests;

public sealed class CreatePermissionRequest
{
    public string Name { get; init; } = string.Empty;
}
