﻿namespace madTypes.Api.Responses;

public class PermissionResponse
{
    public string Id { get; set; } = default!;
    public string Name { get; set; } = default!;
}
