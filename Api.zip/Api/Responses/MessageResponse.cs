﻿namespace madTypes.Api.Responses;

public record MessageResponse(string Message);
