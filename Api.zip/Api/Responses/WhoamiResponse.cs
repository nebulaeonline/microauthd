﻿namespace madTypes.Api.Responses;

public record WhoamiResponse(string Message);
