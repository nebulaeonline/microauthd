﻿namespace madTypes.Api.Responses;

public record ErrorResponse(string Error);
